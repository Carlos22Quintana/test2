
class constants:

    def __init__(self):
        self.speed_light = 299792458  # [m/s]
        self.h_planck = 6.62607004e-34  # [m2 kg / s]
